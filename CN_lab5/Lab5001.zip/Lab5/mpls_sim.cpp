#include <bits/stdc++.h>
using namespace std;

int INF = 1e9;

struct Edge {
    int to;
    int cost;
};

struct RIBEntry {
    int dest;      // Destination router id
    int next_hop;  // Next hop from source towards destination
    int cost;      // Total path cost
};

// Compute Dijkstra and next-hop mapping
vector<RIBEntry> computeRIB(int src, vector<vector<Edge>>& graph) {
    int N = graph.size();
    vector<int> dist(N, INF), parent(N, -1);
    vector<bool> visited(N, false);
    dist[src] = 0;

    priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> pq;
    pq.push({0, src});

    while (!pq.empty()) {
        auto [d, u] = pq.top(); pq.pop();
        if (visited[u]) continue;
        visited[u] = true;

        for (auto e : graph[u]) {
            int v = e.to;
            int nd = d + e.cost;
            if (nd < dist[v]) {
                dist[v] = nd;
                parent[v] = u;
                pq.push({nd, v});
            }
        }
    }

    vector<RIBEntry> table;
    for (int dest = 0; dest < N; dest++) {
        if (dest == src) continue;
        if (dist[dest] == INF) continue;

        int cur = dest, prev = parent[cur];
        while (prev != src && prev != -1) {
            cur = prev;
            prev = parent[cur];
        }
        int next_hop = (prev == -1) ? -1 : cur;
        table.push_back({dest, next_hop, dist[dest]});
    }
    return table;
}

string R(int id) { return "R" + to_string(id); }

void printRoutingTables(vector<vector<Edge>>& graph) {
    int N = graph.size();
    for (int src = 0; src < N; src++) {
        cout << "Routing Table for Router " << R(src) << ":\n";
        cout << "-------------------------------------" << endl;
        cout << "|Destination| Next Hop | Total Cost |\n";
        cout << "-------------------------------------" << endl;
        auto rib = computeRIB(src, graph);
        for (auto &e : rib) {
            cout << "|    " << R(e.dest) << "     |   " << R(e.next_hop)
                 << "     |   " << e.cost << "       |\n";
        }
        cout << "-------------------------------------\n\n";
    }
}

// MPLS Structures
struct Packet {
    int src;
    int dest;
    optional<int> label; // Empty when unlabeled
};

struct IngressLFIBEntry {
    int fec_src;
    int fec_dest;
    int push_label;
    int next_hop;
};

struct TransitLFIBEntry {
    int in_label;
    int out_label;
    int next_hop;
};

struct EgressLFIBEntry {
    int in_label;
};

// Function to find next hop using Dijkstra path
vector<int> getPath(int src, int dest, vector<vector<Edge>>& graph) {
    int N = graph.size();
    vector<int> dist(N, INF), parent(N, -1);
    vector<bool> visited(N, false);
    dist[src] = 0;
    priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> pq;
    pq.push({0, src});

    while (!pq.empty()) {
        auto [d, u] = pq.top(); 
        pq.pop();
        if (visited[u]) continue;

        visited[u] = true;
        for (auto e : graph[u]) {
            int v = e.to;
            int nd = d + e.cost;
            if (nd < dist[v]) {
                dist[v] = nd;
                parent[v] = u;
                pq.push({nd, v});
            }
        }
    }

    vector<int> path;
    for (int v=dest; v!=-1; v=parent[v]){
        path.push_back(v);
    }
    reverse(path.begin(), path.end());
    return path;
}

// Function to simulate packet forwarding
void simulatePacket(int src, int dest, bool useMPLS, vector<vector<Edge>>& graph) {

    cout << "Simulating packet from " << R(src) << " to " << R(dest) << (useMPLS ? " using MPLS...\n" : " using standard IP routing...\n");

    if (!useMPLS) {
        // Normal routing (Dijkstra path traversal)
        vector<int> path = getPath(src, dest, graph);
        if (path.size() <= 1) {
            cout << "No path found!\n";
            return;
        }
        cout << "[IP Routing] Path: ";
        for (int i=0; i<(int)path.size(); i++) {
            cout << R(path[i]);
            if (i != path.size() - 1) cout << " -> ";
        }
        cout << "\nPacket delivered successfully via standard IP routing.\n";
        return;
    }

    // MPLS Simulation
    // MPLS valid only for R0->R3 path
    if (src != 0 || dest != 3) {
        cout << "MPLS label path not configured for this FEC.\n";
        cout << "Falling back to standard IP routing.\n";
        simulatePacket(src, dest, false, graph);
        return;
    }

    IngressLFIBEntry R0_ingress {0, 3, 300, 2};
    TransitLFIBEntry R2_transit {300, 777, 3};
    EgressLFIBEntry R3_egress {777};

    Packet pkt {src, dest, nullopt};

    // R0
    pkt.label = R0_ingress.push_label;
    cout << "[R0] Packet for R3 (FEC: R0->R3). Pushing Label 300. Sending to R2.\n";

    // R2
    pkt.label = R2_transit.out_label;
    cout << "[R2] Received packet with In-Label 300. Swapping for Out-Label 777. Sending to R3.\n";

    // R3
    pkt.label.reset();
    cout << "[R3] Received packet with In-Label 777. Popping label. Packet delivered.\n";
}

int main() {

    // Topology: R0-R1 (10), R0-R2 (20), R1-R3 (20), R2-R3 (10)
    int N = 4;
    vector<vector<Edge>> graph(N);
    auto addLink = [&](int u, int v, int c) {
        graph[u].push_back({v, c});
        graph[v].push_back({u, c});
    };
    addLink(0, 1, 10);
    addLink(0, 2, 20);
    addLink(1, 3, 20);
    addLink(2, 3, 10);

    // Print routing tables
    printRoutingTables(graph);
    
    int src, dest;
    char flag;
    char exit;

    while(true){

        cout << "Enter source router ID (0-3): ";
        cin >> src;
        cout << "Enter destination router ID (0-3): ";
        cin >> dest;
        cout << "Enable MPLS? (y/n): ";
        cin >> flag;
    
        bool useMPLS = (flag == 'y' || flag == 'Y');
        cout << "\n";
        simulatePacket(src, dest, useMPLS, graph);

        cout << "\nWant to simulate again? (y/n): ";
        cin >> exit;
        cout << "\n";
        if(exit == 'n' || exit == 'N') break;

    }

    return 0;
}
