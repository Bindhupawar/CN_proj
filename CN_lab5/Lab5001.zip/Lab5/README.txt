MPLS LABEL FORWARDING SIMULATION
------------------------------------------------------------
230101009 Akshay Bobbala
230101012 Annigandla Kameshwara Rao
230101044 Gunje Manideep Ram
230101067 Muduguru Mahedar Reddy
Course: Computer Networks Laboratory
Language Used: C++17


------------------------------------------------------------
1. FILES INCLUDED
------------------------------------------------------------
1. mpls_sim.cpp     → Source code implementing MPLS and Dijkstra logic
2. output.txt       → Program output (Routing tables + MPLS simulation trace)
3. README.txt       → This file (instructions + analysis answers)
4. Report	    → Lab Report for the assignment
------------------------------------------------------------
2. HOW TO COMPILE AND RUN
------------------------------------------------------------
Compilation:

Linux / macOS:
    g++ -std=c++17 mpls_sim.cpp -o mpls_sim

Windows (MinGW):
    g++ -std=c++17 mpls_sim.cpp -o mpls_sim.exe

Execution:

    ./mpls_sim

The program will:
1. Display routing tables for all routers (R0–R3)
2. Prompt for source and destination router IDs
3. Ask if MPLS should be enabled (y/n)
4. Display either MPLS label operations or standard IP forwarding path

Example Run:
Enter source router ID (0-3): 0
Enter destination router ID (0-3): 3
Enable MPLS? (y/n): y

Simulating packet from R0 to R3 using MPLS...
[R0] Packet for R3 (FEC: R0->R3). Pushing Label 300. Sending to R2.
[R2] Received packet with In-Label 300. Swapping for Out-Label 777. Sending to R3.
[R3] Received packet with In-Label 777. Popping label. Packet delivered.

------------------------------------------------------------
3. ANALYSIS QUESTIONS AND ANSWERS
------------------------------------------------------------

Q1. What is the difference between IP routing and MPLS forwarding?
A1. In IP routing, each router examines the destination IP address and performs a routing table lookup (RIB). In MPLS, routers use a short, fixed-length label to decide the next hop using LFIB. MPLS forwarding is faster and simpler.

------------------------------------------------------------

Q2. Why does MPLS use labels instead of IP addresses?
A2. Labels provide a fixed-length identifier, allowing routers to perform constant-time lookups instead of variable-length prefix matching. This improves scalability and forwarding speed.

------------------------------------------------------------

Q3. What are the roles of ingress, transit, and egress routers in MPLS?
A3.
    - Ingress Router: Pushes a label onto incoming IP packets based on FEC.
    - Transit Router: Swaps the incoming label with a new outgoing label.
    - Egress Router: Pops the label and delivers the original IP packet.

------------------------------------------------------------

Q4. What is the significance of a Forwarding Equivalence Class (FEC)?
A4. A FEC groups packets that are treated identically through the MPLS domain. 
    All packets in the same FEC follow the same Label Switched Path (LSP).

------------------------------------------------------------

Q5. What is the difference between RIB and LFIB?
A5. 
    - RIB (Routing Information Base): Contains IP-based routes and next-hop info. Computed using routing algorithms like Dijkstra.
    - LFIB (Label Forwarding Information Base): Contains label-to-label mappings used for MPLS label swapping.

------------------------------------------------------------

Q6. What are the advantages of MPLS over traditional IP routing?
A6. 
    - Faster packet forwarding (label lookup instead of IP lookup)
    - Supports QoS and Traffic Engineering
    - Enables MPLS VPNs and scalability
    - Simplifies forwarding within backbone networks

------------------------------------------------------------

Q7. What real-world concepts does this simulation represent?
A7. It models:
     - Label distribution (downstream allocation)
     - Label switching (LFIB lookups)
     - Path establishment and delivery (LSP)
     - Core MPLS data-plane behavior (Push–Swap–Pop)

------------------------------------------------------------
END OF README
------------------------------------------------------------
