#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/time.h>

#define DEFAULT_TCP_PORT 8080
#define BUFFER_SIZE 1024

double get_time_sec() {
    struct timeval t;
    gettimeofday(&t, NULL);
    return t.tv_sec + t.tv_usec / 1e6;
}

void udp_summary_csv(int total_msgs, long total_bytes_sent, double start_time, double end_time, int msg_size) {
    
    double total_time = end_time - start_time;
    double throughput = (total_bytes_sent * 8) / (total_time * 1e6);

    FILE *fp = fopen("results.csv", "a");
    if (fp == NULL) {
        perror("Error opening CSV file");
        return;
    }

    fseek(fp, 0, SEEK_END);
    long size = ftell(fp);
    if (size == 0) {
        fprintf(fp, "Message Size(Kilo Bytes),Total Messages,Total Bytes Sent,Total Time(sec),Throughput(Mbps)\n");
    }

    fprintf(fp, "%d,%d,%ld,%.6f,%.6f\n",msg_size, total_msgs, total_bytes_sent, total_time, throughput);

    fclose(fp);
}

void tcp_summary_csv(int total_msgs, long total_bytes_sent, double start_time, double end_time, int msg_size) {
    
    double total_time = end_time - start_time;
    double throughput = (total_bytes_sent * 8) / (total_time * 1e6);

    FILE *fp = fopen("results2.csv", "a");
    if (fp == NULL) {
        perror("Error opening CSV file");
        return;
    }

    fseek(fp, 0, SEEK_END);
    long size = ftell(fp);
    if (size == 0) {
        fprintf(fp, "Message Size(Kilo Bytes),Total Messages,Total Bytes Sent,Total Time(sec),Throughput(Mbps)\n");
    }

    fprintf(fp, "%d,%d,%ld,%.6f,%.6f\n",msg_size, total_msgs, total_bytes_sent, total_time, throughput);

    fclose(fp);
}

int main(int argc, char *argv[]) {
    int tcp_socket, udp_socket;
    struct sockaddr_in server_addr;
    char buffer[BUFFER_SIZE] = {0};
    int udp_port;

    if (argc < 2) {
        printf("Usage: %s <server_ip> [iterations]\n", argv[0]);
        printf("Example: %s 127.0.0.1 1000\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    char *server_ip = argv[1];
    int iterations = 1; 
    if (argc >= 3) {
        iterations = atoi(argv[2]);
        if (iterations <= 0) {
            printf("Invalid iterations. Must be >= 1.\n");
            exit(EXIT_FAILURE);
        }
    }

    // Phase 1: TCP Communication
    if ((tcp_socket = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        perror("TCP socket failed");
        exit(EXIT_FAILURE);
    }

    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(DEFAULT_TCP_PORT);

    if (inet_pton(AF_INET, server_ip, &server_addr.sin_addr) <= 0) {
        perror("Invalid address");
        exit(EXIT_FAILURE);
    }

    if (connect(tcp_socket, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("TCP connection failed");
        exit(EXIT_FAILURE);
    }

    printf("Connected to server %s via TCP\n", server_ip);

    // Start timing for performance measurement - TCP
    double start_time = get_time_sec();
    int total_msgs = 1;
    long total_bytes_sent = 18;

    // Send Type 1 message
    char *request = "1:18:Request for UDP port";
    send(tcp_socket, request, strlen(request), 0);
    printf("Sent Type 1 message\n");

    // Receive Type 2 response
    int n = read(tcp_socket, buffer, BUFFER_SIZE);
    if (n > 0) {
        buffer[n] = '\0';
        printf("Received Type 2 message: %s\n", buffer);

        if (sscanf(buffer, "2:4:%d", &udp_port) == 1) {
            printf("Negotiated UDP port: %d\n", udp_port);
        } else {
            printf("Error parsing UDP port\n");
            close(tcp_socket);
            exit(EXIT_FAILURE);
        }
    }

    
    close(tcp_socket);

    double end_time = get_time_sec();
    double total_time = end_time - start_time;

    printf("\nTCP Transmission Summary:\n");
    printf("Total Messages Sent : %d\n", total_msgs);
    printf("Total Bytes Sent    : %ld bytes\n", total_bytes_sent);
    printf("Total Time Taken    : %.6f seconds\n", total_time);
    printf("Throughput          : %.3f Mbps\n\n", (total_bytes_sent * 8) / (total_time * 1e6));
    //tcp_summary_csv(total_msgs, total_bytes_sent, start_time, end_time, iterations);

    printf("TCP connection closed\n");

    // Phase 2: UDP Communication
    if ((udp_socket = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
        perror("UDP socket failed");
        exit(EXIT_FAILURE);
    }

    struct timeval tv;
    tv.tv_sec = 5;
    tv.tv_usec = 0;
    setsockopt(udp_socket, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));

    server_addr.sin_port = htons(udp_port);

    FILE *fp = fopen("sample.txt", "r");
    if (!fp) {
        perror("File open failed");
        exit(EXIT_FAILURE);
    }

    char response[BUFFER_SIZE];
    char buffer1[BUFFER_SIZE - 10];
    total_msgs = 0;
    total_bytes_sent = 0;

    // Start timing for performance measurement - UDP
    start_time = get_time_sec();

    // Send the file multiple times based on iterations
    for (int round = 1; round <= iterations; round++) {
        rewind(fp); // Reset file pointer for each iteration

        while (fgets(buffer1, sizeof(buffer1), fp)) {
            buffer1[strcspn(buffer1, "\n")] = '\0';
            int datalen = strlen(buffer1);
            snprintf(response, BUFFER_SIZE, "3:%d:%s", datalen, buffer1);
            sendto(udp_socket, response, strlen(response), 0,(struct sockaddr *)&server_addr, sizeof(server_addr));
            total_msgs++;
            total_bytes_sent += datalen;
        }
        //printf("sent %d round\n",round);
    }

    // Send final Bye message
    sendto(udp_socket, "Bye", strlen("Bye"), 0, (struct sockaddr *)&server_addr, sizeof(server_addr));
    total_msgs++;

    end_time = get_time_sec();
    total_time = end_time - start_time;

    printf("\nUDP Transmission Summary:\n");
    printf("Total Messages Sent : %d\n", total_msgs);
    printf("Total Bytes Sent    : %ld bytes\n", total_bytes_sent);
    printf("Total Time Taken    : %.3f seconds\n", total_time);
    printf("Throughput          : %.3f Mbps\n\n", (total_bytes_sent * 8) / (total_time * 1e6));
    //udp_summary_csv(total_msgs, total_bytes_sent, start_time, end_time, iterations);

    // Receive Type 4 response
    socklen_t server_len = sizeof(server_addr);
    n = recvfrom(udp_socket, buffer, BUFFER_SIZE, 0, (struct sockaddr *)&server_addr, &server_len);
    if (n > 0) {
        buffer[n] = '\0';
        printf("Received Type 4 response: %s\n", buffer);
    } 
    else {
        printf("Server did not respond to Bye (possible packet loss)\n");
    }

    close(udp_socket);
    fclose(fp);
    printf("UDP communication completed\n");

    return 0;
}
