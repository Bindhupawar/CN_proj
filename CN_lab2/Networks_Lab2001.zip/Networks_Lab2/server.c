#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <sys/time.h>

#define MAX_CLIENTS 10 // Maximum parallel TCP Connections
#define BUFFER_SIZE 65536 // 64KB
#define QUEUE_SIZE 10 // Maximum UDP Connections
#define TIME_SLOT 60000 // Round Robin Time Slice (No of max messages in a time slot)

typedef struct {
    int client_socket;
    struct sockaddr_in client_addr;
    int udp_socket;
    int udp_port;
    int served;
    int successfull_recieved;
} ClientRequest;

typedef struct {
    ClientRequest requests[QUEUE_SIZE];
    int front, rear;
    int count;
    pthread_mutex_t lock;
    pthread_cond_t not_empty;
} RequestQueue;

typedef enum {
    FCFS,
    RR
} SchedulingPolicy;

RequestQueue queue;
SchedulingPolicy policy;

void init_queue() {
    queue.front = 0;
    queue.rear = -1;
    queue.count = 0;
    pthread_mutex_init(&queue.lock, NULL);
    pthread_cond_init(&queue.not_empty, NULL);
}

void enqueue(ClientRequest req) {
    pthread_mutex_lock(&queue.lock);
    
    if (queue.count < QUEUE_SIZE) {
        queue.rear = (queue.rear + 1) % QUEUE_SIZE;
        queue.requests[queue.rear] = req;
        queue.count++;
        pthread_cond_signal(&queue.not_empty);
    }
    
    pthread_mutex_unlock(&queue.lock);
}

ClientRequest* dequeue_fcfs() {
    pthread_mutex_lock(&queue.lock);
    
    while (queue.count == 0) {
        pthread_cond_wait(&queue.not_empty, &queue.lock);
    }
    
    ClientRequest *req = &queue.requests[queue.front];
    queue.front = (queue.front + 1) % QUEUE_SIZE;
    queue.count--;
    
    pthread_mutex_unlock(&queue.lock);
    return req;
}

ClientRequest* dequeue_rr() {
    pthread_mutex_lock(&queue.lock);
    
    while (queue.count == 0) {
        pthread_cond_wait(&queue.not_empty, &queue.lock);
    }
    
    // Round Robin: Find the next client that hasn't been served yet
    ClientRequest *req;
    int found = 0;
    
    for (int i = 0; i < queue.count; i++) {
        int index = (queue.front + i) % QUEUE_SIZE;
        if (!queue.requests[index].served) {
            req = &queue.requests[index];
            queue.requests[index].served = 1; // Mark as served
            found = 1;
            break;
        }
    }
    
    // If all clients have been served in this cycle, reset and start new cycle
    if (!found) {
        for (int i = 0; i < queue.count; i++) {
            int index = (queue.front + i) % QUEUE_SIZE;
            queue.requests[index].served = 0; // Reset all
        }
        req = &queue.requests[queue.front];
        queue.requests[queue.front].served = 1;
    }
    
    pthread_mutex_unlock(&queue.lock);
    return req;
}

void remove_completed(ClientRequest req){
    pthread_mutex_lock(&queue.lock);

    for (int i = 0; i < queue.count; i++) {
        int index = (queue.front + i) % QUEUE_SIZE;
        if (queue.requests[index].udp_port == req.udp_port) {
            for (int j = i; j < queue.count - 1; j++) {
                int current_pos = (queue.front + j) % QUEUE_SIZE;
                int next_pos = (queue.front + j + 1) % QUEUE_SIZE;
                queue.requests[current_pos] = queue.requests[next_pos];
            }
            queue.count--;
            queue.rear = (queue.rear - 1 + QUEUE_SIZE) % QUEUE_SIZE;
        }
    }

    if (queue.count > 0) {
        printf("Remaining Connections: ");
        int n = 0;

        for (int i = queue.front; n < queue.count; i = (i + 1) % QUEUE_SIZE) {
            printf("%s:%d, ",inet_ntoa(queue.requests[i].client_addr.sin_addr),ntohs(queue.requests[i].client_addr.sin_port));
            n++;
        }
        printf("\n");
    } 
    else {
        printf("No remaining active connections.\n");
    }

    pthread_mutex_unlock(&queue.lock);
}


void handle_udp_connection(ClientRequest *req) {

    int udp_socket = req->udp_socket;
    struct sockaddr_in client_addr=req->client_addr;
    socklen_t client_len = sizeof(client_addr);
    char buffer[BUFFER_SIZE] = {0};

    if(policy == FCFS){

        printf("Started recieving messages for client %s:%d on thread %ld\n", inet_ntoa(req->client_addr.sin_addr), ntohs(req->client_addr.sin_port), pthread_self());
        int noofmsgs=0;
        while(1){
            int n = recvfrom(udp_socket, buffer, BUFFER_SIZE, 0, (struct sockaddr *)&client_addr, &client_len);
            if (n > 0) {
                buffer[n] = '\0';
                noofmsgs++;
                req->successfull_recieved++;
                //printf("Client: %s\n", buffer);
            }
            
            if (n < 0) {
                perror("Timedout or error");
                printf("Successfully recieved %d messages\n", req->successfull_recieved);
                remove_completed(*req);
                close(udp_socket);
                return ;
            }
            if(strcmp("Bye",buffer)==0) {
                // Send Type 4 response
                char *response = "4:26:Data received successfully";
                sendto(udp_socket, response, strlen(response), 0,(struct sockaddr *)&client_addr, client_len);
                printf("Successfully recieved %d messages\n", req->successfull_recieved);
                printf("Sent Type 4 response\n");
                close(udp_socket);
                printf("UDP communication completed\n");
                printf("Completed for client %s:%d on thread %ld\n", inet_ntoa(req->client_addr.sin_addr), ntohs(req->client_addr.sin_port), pthread_self());
                return ;
            }
        }
        return ;
    }
    int noofmsgs=0;
    while(noofmsgs<TIME_SLOT){
        int n = recvfrom(udp_socket, buffer, BUFFER_SIZE, 0, (struct sockaddr *)&client_addr, &client_len);
        if (n > 0) {
            buffer[n] = '\0';
            noofmsgs++;
            req->successfull_recieved++;
            //printf("Client: %s\n", buffer);
        }
        if (n < 0) {
            perror("Timedout or error");
            printf("Successfully recieved %d messages\n", req->successfull_recieved);
            remove_completed(*req);
            close(udp_socket);
            return ;
        }
        if(strcmp("Bye",buffer)==0) {
            // Send Type 4 response
            char *response = "4:26:Data received successfully";
            sendto(udp_socket, response, strlen(response), 0,(struct sockaddr *)&client_addr, client_len);
            printf("Successfully recieved %d messages\n", req->successfull_recieved);
            printf("Sent Type 4 response\n");
            remove_completed(*req);
            close(udp_socket);
            printf("UDP communication completed\n");
            return ;
        }
    }

    if (policy == RR) {
            printf("Completed time slice for client %s:%d on thread %ld\n", inet_ntoa(req->client_addr.sin_addr), ntohs(req->client_addr.sin_port), pthread_self());
    }
    
    return;

}



void* thread(void* arg) {
    while (1) {
        ClientRequest *req;
        
        if (policy == FCFS) {
            req = dequeue_fcfs();
        } else {
            req = dequeue_rr();
        }
      
        handle_udp_connection(req);

    }
    return NULL;
}

int main(int argc, char *argv[]) {

    if (argc != 3) {
        printf("Usage: %s <port> <scheduling_policy>\n", argv[0]);
        printf("Scheduling policies: 0=FCFS, 1=RR\n");
        exit(EXIT_FAILURE);
    }
    
    int port = atoi(argv[1]);
    policy = atoi(argv[2]);
    
    if (policy != FCFS && policy != RR) {
        printf("Invalid scheduling policy. Use 0 for FCFS, 1 for RR\n");
        exit(EXIT_FAILURE);
    }
    
    int server_tcp_socket;
    struct sockaddr_in address;
    int opt = 1;
    int addrlen = sizeof(address);
    
    init_queue();
    
    // Create TCP socket
    if ((server_tcp_socket = socket(AF_INET, SOCK_STREAM, 0)) == 0) {
        perror("TCP socket failed");
        exit(EXIT_FAILURE);
    }
    
    if (setsockopt(server_tcp_socket, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt))) {
        perror("setsockopt failed");
        exit(EXIT_FAILURE);
    }
    
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons(port);
    
    if (bind(server_tcp_socket, (struct sockaddr *)&address, sizeof(address)) < 0) {
        perror("TCP bind failed");
        exit(EXIT_FAILURE);
    }
    
    if (listen(server_tcp_socket, MAX_CLIENTS) < 0) {
        perror("TCP listen failed");
        exit(EXIT_FAILURE);
    }
    
    printf("Server started on port %d with %s scheduling\n", port, policy == FCFS ? "FCFS" : "Round-Robin");
    
    
    pthread_t threads[4];
    for (int i = 0; i < 4; i++) {
        pthread_create(&threads[i], NULL, thread, NULL);
    }
    

    while (1) {

        int new_socket;
        struct sockaddr_in client_addr;
        socklen_t client_len = sizeof(client_addr);
        
        if ((new_socket = accept(server_tcp_socket, (struct sockaddr *)&client_addr, &client_len)) < 0) {
            perror("TCP accept failed");
            continue;
        }
        
        printf("New client connected: %s:%d\n", inet_ntoa(client_addr.sin_addr), ntohs(client_addr.sin_port));
        
        
        ClientRequest req;
        req.client_socket = new_socket;
        req.client_addr = client_addr;
        req.served = 0;
        req.successfull_recieved =0;

        char buffer[BUFFER_SIZE] = {0};
        int udp_port;

        // Read Type 1 message
        read(new_socket, buffer, BUFFER_SIZE);
        printf("Client: %s\n", buffer);

        
        udp_port = 9000 + (rand() % 1000);
        req.udp_port = udp_port;

        // Send Type 2 message (UDP port number)
        char response[BUFFER_SIZE];
        snprintf(response, BUFFER_SIZE, "2:4:%d", udp_port);
        send(new_socket, response, strlen(response), 0);
        printf("Sent Type 2 message with UDP port: %d\n", udp_port);

        // Close TCP connection
        close(new_socket);
        printf("TCP connection closed\n");

        int udp_socket;
        struct sockaddr_in server_addr;

        // Create UDP socket
        if ((udp_socket = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
            perror("UDP socket failed");
            continue;
        }

        struct timeval tv;
        tv.tv_sec = 5;   // 5 seconds timeout
        tv.tv_usec = 0;
        setsockopt(udp_socket, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));

        req.udp_socket = udp_socket;

        server_addr.sin_family = AF_INET;
        server_addr.sin_addr.s_addr = INADDR_ANY;
        server_addr.sin_port = htons(req.udp_port);

        // Bind UDP socket
        if (bind(udp_socket, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
            perror("UDP bind failed");
            close(udp_socket);
            continue;
        }

        printf("Waiting for UDP data on port %d...\n", req.udp_port);
        enqueue(req);
    }
    
    close(server_tcp_socket);
    return 0;
}