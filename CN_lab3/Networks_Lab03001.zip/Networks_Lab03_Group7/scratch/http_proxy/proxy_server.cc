#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/internet-module.h"
#include "ns3/applications-module.h"
#include "ns3/point-to-point-module.h"
#include "ns3/csma-module.h"
#include <map>
#include <vector>
#include <sstream>

using namespace ns3;

NS_LOG_COMPONENT_DEFINE("ProxyServerSimulation");

// HTTP Cache implementation (LRU)
class HttpCache {
    private:
        struct CacheEntry {
            std::string content;
            Time timestamp;
            uint32_t size;
            uint32_t access_count;
        };
        
        std::map<std::string, CacheEntry> cache;
        uint32_t hits;
        uint32_t misses;
        uint32_t max_size;
        
    public:
        HttpCache(uint32_t max_cache_size=100){
            hits=0;
            misses=0;
            max_size=max_cache_size;
        }
        
        bool hasContent(const std::string& url) {
            auto it=cache.find(url);
            if (it!=cache.end()) {
                // Check if cache entry is still valid (10 second TTL)
                if (Simulator::Now()-it->second.timestamp < Seconds(10)) {
                    hits++;
                    it->second.access_count++;
                    return true;
                } else {
                    // Cache expired
                    cache.erase(it);
                }
            }
            misses++;
            return false;
        }
        
        std::string getContent(const std::string& url) {
            auto it=cache.find(url);
            if (it!=cache.end()) {
                return it->second.content;
            }
            return "";
        }
        
        void storeContent(const std::string& url, const std::string& content, uint32_t size) {
            
            if (cache.size()>=max_size) {
                // Remove least frequently last used
                std::string LRU_KEY;
                uint32_t min_access=UINT32_MAX;
                Time min_time=Simulator::Now();
                for (const auto& entry:cache) {
                    if (entry.second.access_count<=min_access) {
                        if(entry.second.timestamp<min_time){
                            min_access=entry.second.access_count;
                            LRU_KEY=entry.first;
                        }
                    }
                }
                if(!LRU_KEY.empty()){
                    cache.erase(LRU_KEY);
                }
            }
            
            CacheEntry entry;
            entry.content=content;
            entry.timestamp=Simulator::Now();
            entry.size=size;
            entry.access_count=1;
            cache[url]=entry;
            
            NS_LOG_INFO("Cached: "<<url<<" Size: "<< size<<" bytes");
        }
        
        double getHitRatio() const {
            uint32_t total=hits+misses;
            return total>0 ? (double)hits/total : 0.0;
        }
        
        uint32_t getHits() const { 
            return hits; 
        }
        uint32_t getMisses() const { 
            return misses; 
        }
        uint32_t getCacheSize() const { 
            return cache.size(); 
        }
        
        void clear() {
            cache.clear();
            hits=0;
            misses=0;
        }
};

// Web Server Application
class WebServer: public Application {

    private:

        uint16_t port;
        std::map<std::string, std::string> server_content;
        std::map<std::string, uint32_t> content_size;

        void InitializeContent() {
            
            server_content["/index.html"]= "<html><body><h1>Welcome to Website 1</h1><p>Home page content</p></body></html>";
            server_content["/about.html"]= "<html><body><h1>About Us</h1><p>Company information</p></body></html>";
            server_content["/products.html"]= "<html><body><h1>Our Products</h1><p>Product catalog</p></body></html>";
            server_content["/images/logo.jpg"]= "JPEG_IMAGE_DATA_LOGO";
            server_content["/images/banner.png"]= "PNG_IMAGE_DATA_BANNER";
            server_content["/data/api.json"]= "{\"data\": \"JSON API Response\"}";
            server_content["/videos/intro.mp4"]= "VIDEO_DATA_INTRODUCTION";
            server_content["/documents/report.pdf"]= "PDF_DOCUMENT_REPORT";
            
            content_size["/index.html"]= 1200;
            content_size["/about.html"]= 800;
            content_size["/products.html"]= 1500;
            content_size["/images/logo.jpg"]= 50000;
            content_size["/images/banner.png"]= 75000;
            content_size["/data/api.json"]= 200;
            content_size["/videos/intro.mp4"]= 200000;
            content_size["/documents/report.pdf"]= 100000;
        }
        
        void HandleRead(Ptr<Socket> socket) {

            Ptr<Packet> packet;
            Address from;
            
            while ((packet=socket->RecvFrom(from))) {
                uint8_t buffer[1024];
                packet->CopyData(buffer, packet->GetSize());
                std::string request((char*)buffer, packet->GetSize());
                
                NS_LOG_INFO("\nWebServer received: "<<request);
                
                // Parsing HTTP GET request
                std::string response=ProcessHttpRequest(request);
                
                // Sending HTTP response
                Ptr<Packet> respPacket=Create<Packet>((uint8_t*)response.c_str(), response.length());
                socket->SendTo(respPacket,0,from);
                
                NS_LOG_INFO("WebServer sent response for request");
            }
        }
        
        std::string ProcessHttpRequest(const std::string& request) {
            // HTTP request parsing
            if (request.find("GET ")==0) {
                size_t start=4; // After "GET "
                size_t end=request.find(" HTTP/");
                if (end != std::string::npos) {
                    std::string url=request.substr(start, end-start);
                    
                    if (server_content.find(url) != server_content.end()) {
                        // Server processing time (5-20ms)
                        uint32_t processingTime=5+(rand()%15);
                        
                        std::stringstream response;
                        response<<"HTTP/1.1 200 OK\r\n";
                        response<<"Content-Type: text/html\r\n";
                        response<<"Content-Length: "<<server_content[url].length()<<"\r\n";
                        response<<"Server: WebServer/1.0\r\n";
                        response<<"\r\n";
                        response<<server_content[url];
                        
                        NS_LOG_INFO("WebServer processing "<<url<<" ("<<processingTime<<"ms)");
                        return response.str();
                    }
                }
            }
            
            // 404 Not Found
            return "HTTP/1.1 404 Not Found\r\nContent-Length: 0\r\n\r\n";
        }
        
        void StartApplication() override {
            Ptr<Socket> socket=Socket::CreateSocket(GetNode(), UdpSocketFactory::GetTypeId());
            InetSocketAddress local=InetSocketAddress(Ipv4Address::GetAny(), port);
            socket->Bind(local);
            socket->SetRecvCallback(MakeCallback(&WebServer::HandleRead, this));
            
            NS_LOG_INFO("WebServer started on port " << port);
        }
        
        void StopApplication() override {} // Server is always ON

    public:
        static TypeId GetTypeId() {
            static TypeId tid = TypeId("WebServer").SetParent<Application>().AddConstructor<WebServer>();
            return tid;
        }
        
        WebServer(){
            port=80;
            InitializeContent();
        }
        
        void SetPort(uint16_t p) { 
            port=p; 
        }

};

uint32_t requests_for_throughput=0;
std::ofstream throughputLog("throughput.txt");
void LogThroughput() {
  double currentTime=Simulator::Now().GetSeconds();
  double throughput_bps=(requests_for_throughput)/currentTime;
  throughputLog<<currentTime<<" "<<throughput_bps<<"\n";
  Simulator::Schedule(Seconds(0.5), &LogThroughput);
}

// Proxy Server Application
class ProxyServer : public Application {

    private:

        struct RequestContext {
            Ptr<Socket> client_socket;
            Address client_address;
            std::string url;
            Time startTime;
            Ptr<Socket> server_socket;
        };
        
        HttpCache* cache;
        uint32_t total_requests;
        uint16_t port;
        std::vector<std::pair<Ipv4Address, uint16_t>> web_servers;
        std::map<Ptr<Socket>, RequestContext> pending_requests;
        
        std::vector<Time> response_times;
        std::vector<Time> cached_response_times;
        std::vector<Time> uncached_response_times;

        void HandleRead(Ptr<Socket> socket) {
            Ptr<Packet> packet;
            Address from;
            
            while ((packet=socket->RecvFrom(from))) {
                requests_for_throughput++;
                uint8_t buffer[2048];
                packet->CopyData(buffer, packet->GetSize());
                std::string request((char*)buffer, packet->GetSize());
                
                NS_LOG_INFO("\nProxy received request from "<<InetSocketAddress::ConvertFrom(from).GetIpv4());
                
                ProcessHttpRequest(request, socket, from);
            }
        }
        
        void ProcessHttpRequest(const std::string& request, Ptr<Socket> socket, const Address& from) {
            Time startTime = Simulator::Now();
            total_requests++;
            
            // Parsing the URL from GET request
            std::string url=ExtractUrlFromRequest(request);
            
            if(url.empty()) {
                SendErrorResponse(socket, from, "400 Bad Request");
                return;
            }
            
            NS_LOG_INFO("\nProxy processing: "<<url);
            
            // Checking cache first
            if (cache->hasContent(url)) {
                NS_LOG_INFO("CACHE HIT: "<<url);
                std::string cached_content=cache->getContent(url);
                // Serve from cache (FAST)
                Simulator::Schedule(Seconds(0.001), &ProxyServer::SendCachedResponse, this, socket, from, cached_content, startTime);
            } 
            else {
                NS_LOG_INFO("CACHE MISS: " << url);
                // Forward to web server (SLOW)
                Simulator::Schedule(Seconds(0.002), &ProxyServer::ForwardToWebServer, this, socket, from, request, url, startTime);
            }
        }
        
        std::string ExtractUrlFromRequest(const std::string& request) {
            if (request.find("GET ") == 0) {
                size_t start=4;
                size_t end=request.find(" HTTP/");
                if (end!=std::string::npos) {
                    return request.substr(start, end-start);
                }
            }
            return "";
        }
        
        void ForwardToWebServer(Ptr<Socket> socket, const Address& client_address, const std::string& request, const std::string& url, Time startTime) {
            if (web_servers.empty()) {
                SendErrorResponse(socket, client_address, "503 No Web Servers Available");
                return;
            }
            
            // Finding the web server (Based on URL)
            uint32_t server_index=std::hash<std::string>{}(url)%web_servers.size();
            auto& server=web_servers[server_index];
            
            // Creating socket to contact web server
            Ptr<Socket> server_socket=Socket::CreateSocket(GetNode(), UdpSocketFactory::GetTypeId());
            InetSocketAddress serverAddress(server.first, server.second);
            
            // Sending request to web server
            Ptr<Packet> packet=Create<Packet>((uint8_t*)request.c_str(), request.length());
            server_socket->SendTo(packet, 0, serverAddress);
            
            NS_LOG_INFO("Proxy forwarded to web server: "<<server.first<<":"<<server.second);
            
            // Scheduling receiving response from web server
            server_socket->SetRecvCallback(MakeCallback(&ProxyServer::HandleWebServerResponse, this));
            
            // Store context for when we get the response
            RequestContext context;
            context.client_socket=socket;
            context.client_address=client_address;
            context.url=url;
            context.startTime=startTime;
            context.server_socket=server_socket;
            
            pending_requests[server_socket]=context;
        }
        
        void HandleWebServerResponse(Ptr<Socket> socket) {
            Ptr<Packet> packet;
            Address from;
            
            while ((packet=socket->RecvFrom(from))) {
                auto it=pending_requests.find(socket);
                if (it!=pending_requests.end()) {
                    RequestContext& context=it->second;
                    
                    uint8_t buffer[4096];
                    packet->CopyData(buffer, packet->GetSize());
                    std::string response((char*)buffer, packet->GetSize());
                    
                    // Caching the response if it's successful
                    if (response.find("HTTP/1.1 200")==0) {
                        size_t headerEnd=response.find("\r\n\r\n");
                        if (headerEnd!=std::string::npos) {
                            std::string content=response.substr(headerEnd+4);
                            cache->storeContent(context.url, content, content.length());
                        }
                    }
                    
                    // Forwarding response to client
                    Ptr<Packet> respPacket=Create<Packet>((uint8_t*)response.c_str(), response.length());
                    context.client_socket->SendTo(respPacket, 0, context.client_address);
                    
                    Time responseTime=Simulator::Now()-context.startTime;
                    uncached_response_times.push_back(responseTime);
                    response_times.push_back(responseTime);
                    
                    NS_LOG_INFO("\nProxy forwarded web server response to client at "<<InetSocketAddress::ConvertFrom(context.client_address).GetIpv4()<<":"<< InetSocketAddress::ConvertFrom(context.client_address).GetPort()<<", Response time: "<<responseTime.GetDouble()/1000000<<"ms");
                    
                    pending_requests.erase(it);
                }
            }
        }
        
        void SendCachedResponse(Ptr<Socket> socket, const Address& client_address, const std::string& content, Time startTime) {
            std::stringstream response;
            response<<"HTTP/1.1 200 OK\r\n";
            response<<"Content-Type: text/html\r\n";
            response<<"Content-Length: "<<content.length()<<"\r\n";
            response<<"X-Cache: HIT\r\n";
            response<<"Server: ProxyCache/1.0\r\n";
            response<<"\r\n";
            response<<content;
            
            Ptr<Packet> packet=Create<Packet>((uint8_t*)response.str().c_str(), response.str().length());
            socket->SendTo(packet, 0, client_address);
            
            Time responseTime= Simulator::Now()-startTime;
            cached_response_times.push_back(responseTime);
            response_times.push_back(responseTime);
            
            NS_LOG_INFO("\nProxy served from cache to client at "<<InetSocketAddress::ConvertFrom(client_address).GetIpv4()<<":"<< InetSocketAddress::ConvertFrom(client_address).GetPort()<<", Response time: "<<responseTime.GetDouble()/1000000<<"ms");
        }
        
        void SendErrorResponse(Ptr<Socket> socket, const Address& client_address, const std::string& error) {
            std::string response= "HTTP/1.1 "+error+"\r\nContent-Length: 0\r\n\r\n";
            Ptr<Packet> packet=Create<Packet>((uint8_t*)response.c_str(), response.length());
            socket->SendTo(packet, 0, client_address);
        }
        
        void StartApplication() override {
            Ptr<Socket> socket=Socket::CreateSocket(GetNode(), UdpSocketFactory::GetTypeId());
            InetSocketAddress local=InetSocketAddress(Ipv4Address::GetAny(), port);
            socket->Bind(local);
            socket->SetRecvCallback(MakeCallback(&ProxyServer::HandleRead, this));
            
            NS_LOG_INFO("Proxy Server started on port "<<port);
        }
        
        void StopApplication() override {} // Always ON Proxy Server
        
    public:
        static TypeId GetTypeId() {
            static TypeId tid=TypeId("ProxyServer").SetParent<Application>().AddConstructor<ProxyServer>().AddAttribute("Port", "Listening port",UintegerValue(8080),MakeUintegerAccessor(&ProxyServer::port),MakeUintegerChecker<uint16_t>());
            return tid;
        }
        
        ProxyServer() : cache(new HttpCache(50)){
            total_requests=0;
            port=8080;
        }
        
        virtual ~ProxyServer() {
            delete cache;
        }
        
        void AddWebServer(Ipv4Address address, uint16_t port=80) {
            web_servers.push_back(std::make_pair(address, port));
        }
        void PrintStats() {

            NS_LOG_INFO("\n\n               Proxy Server Statistics\n");
            NS_LOG_INFO("               Total requests processed: "<<total_requests);
            NS_LOG_INFO("               Cache hits: "<<cache->getHits());
            NS_LOG_INFO("               Cache misses: "<<cache->getMisses());
            NS_LOG_INFO("               Cache hit ratio: "<<(cache->getHitRatio()*100)<< "%");
            NS_LOG_INFO("               Current cache size: "<<cache->getCacheSize()<<" objects");
            NS_LOG_INFO("               Current pending requests: "<<pending_requests.size());
            
            if(!response_times.empty()) {
                Time totalTime=Seconds(0);
                for (const auto& time:response_times) {
                    totalTime+=time;
                }
                NS_LOG_INFO("               Average response time: "<<(totalTime.GetDouble()/1000000)/response_times.size()<<"ms");
            }
            
            if(!cached_response_times.empty()) {
                Time totalTime=Seconds(0);
                for (const auto& time:cached_response_times) {
                    totalTime+=time;
                }
                NS_LOG_INFO("               Average cached response time: "<<(totalTime.GetDouble()/1000000)/cached_response_times.size()<<"ms");
            }
            
            if(!uncached_response_times.empty()) {
                Time totalTime=Seconds(0);
                for (const auto& time:uncached_response_times) {
                    totalTime+=time;
                }
                NS_LOG_INFO("               Average uncached response time: "<<(totalTime.GetDouble()/1000000)/uncached_response_times.size()<<"ms\n\n");
            }
        }

};

// HTTP Client Application
class HttpClient: public Application {

    private:

        Ptr<Socket> socket;
        Address proxy_address;
        std::vector<std::string> request_urls;
        std::map<std::string, Time> request_start_times;
        uint32_t requests_sent;
        uint32_t request_recieved;
        uint32_t client_no;

        void StartApplication() override {
            socket=Socket::CreateSocket(GetNode(), UdpSocketFactory::GetTypeId());
            InetSocketAddress localAddr(Ipv4Address::GetAny(), 9000+client_no);
            socket->Bind(localAddr);

            socket->SetRecvCallback(MakeCallback(&HttpClient::HandleResponse, this));
            
            if(!request_urls.empty()) {
                Simulator::Schedule(Seconds(1.0), &HttpClient::SendHttpRequest, this, 0);
            }
            NS_LOG_INFO("Client bound to "<<InetSocketAddress::ConvertFrom(localAddr).GetIpv4()<<":"<<InetSocketAddress::ConvertFrom(localAddr).GetPort());

        }
        
        void StopApplication() override{
            if(socket) {
                socket->Close();
            }
        }
        
        void SendHttpRequest(uint32_t urlIndex) {
            if (urlIndex>=request_urls.size()) return;
            
            std::string url=request_urls[urlIndex];
            std::stringstream request;
            request<<"GET "<<url<< " HTTP/1.1\r\n";
            request<<"Host: proxy\r\n";
            request<<"User-Agent: HttpClient/1.0\r\n";
            request<<"Accept: */*\r\n";
            request<<"\r\n";
            
            Ptr<Packet> packet=Create<Packet>((uint8_t*)request.str().c_str(), request.str().length());
            socket->SendTo(packet, 0, proxy_address);
            
            request_start_times[url]=Simulator::Now();
            requests_sent++;
            
            NS_LOG_INFO("\nClient "<<client_no<<" sent GET request: "<<url);
            
            // Scheduling next request
            if(urlIndex+1 < request_urls.size()) {
                double interval = 2.0+(rand()%100)/100.0;
                Simulator::Schedule(Seconds(interval), &HttpClient::SendHttpRequest, this, urlIndex+1);
            }
            
            // Repeated requests to demonstrate caching
            if(urlIndex<3) { // Repeat first few URLs
                double repeatInterval = 5.0+ (rand()%100)/100.0;
                Simulator::Schedule(Seconds(repeatInterval), &HttpClient::SendHttpRequest, this, urlIndex);
            }
        }
        
        void HandleResponse(Ptr<Socket> socket) {
            Ptr<Packet> packet;
            Address from;
            
            while ((packet = socket->RecvFrom(from))) {
                uint8_t buffer[4096];
                packet->CopyData(buffer, packet->GetSize());
                std::string response((char*)buffer, packet->GetSize());
                request_recieved++;
                
                InetSocketAddress srcAddr=InetSocketAddress::ConvertFrom(from);
                NS_LOG_INFO("\nClient "<<client_no<<" received response from "<<srcAddr.GetIpv4()<<":"<<srcAddr.GetPort());
                NS_LOG_INFO("Response content:\n"<<response);
            }
        }

    public:
        static TypeId GetTypeId() {
            static TypeId tid = TypeId("HttpClient").SetParent<Application>().AddConstructor<HttpClient>();
            return tid;
        }
        
        HttpClient(uint32_t client_number=0) {
            socket=0;
            requests_sent=0;
            request_recieved=0;
            client_no=client_number;
        }
        
        void SetProxyServer(Address address) {
            proxy_address=address;
        }
        
        void Setrequest_urls(const std::vector<std::string>& urls) {
            request_urls=urls;
        }

};

int main(int argc, char *argv[]) {

    uint32_t no_clients=3;
    double simulation_time=20.0;
    
    CommandLine cmd;
    cmd.AddValue("no_clients", "Number of client nodes", no_clients);
    cmd.AddValue("simulation_time", "Simulation time in seconds", simulation_time);
    cmd.Parse(argc, argv);
    
    LogComponentEnable("ProxyServerSimulation", LOG_LEVEL_INFO);
    // LogComponentEnable("ProxyServer", LOG_LEVEL_DEBUG);
    // LogComponentEnable("WebServer", LOG_LEVEL_DEBUG);
    // LogComponentEnable("HttpClient", LOG_LEVEL_DEBUG);
    
    NS_LOG_INFO("Creating network topology...");
    
    // Creating nodes: proxy, web servers, clients
    NodeContainer proxyNode;
    proxyNode.Create(1);
    
    NodeContainer webServerNodes;
    webServerNodes.Create(3); // 3 different web servers
    
    NodeContainer clientNodes;
    clientNodes.Create(no_clients);
    
    // Combining all nodes into one container for network installation
    NodeContainer allNodes;
    allNodes.Add(proxyNode);
    allNodes.Add(webServerNodes);
    allNodes.Add(clientNodes);
    
    // Creating CSMA network
    CsmaHelper csma;
    csma.SetChannelAttribute("DataRate", StringValue("100Mbps"));
    csma.SetChannelAttribute("Delay", TimeValue(MicroSeconds(2)));
    
    NetDeviceContainer devices;
    devices=csma.Install(allNodes);
    
    // Installing internet stack
    InternetStackHelper stack;
    stack.Install(allNodes);
    
    // Assign IP addresses
    Ipv4AddressHelper address;
    address.SetBase("10.1.1.0", "255.255.255.0");
    Ipv4InterfaceContainer interfaces=address.Assign(devices);
    
    // Setting up Web Servers
    std::vector<Ptr<WebServer>> web_servers;
    for (uint32_t i=0; i<webServerNodes.GetN(); i++) {
        Ptr<WebServer> server=CreateObject<WebServer>();
        server->SetPort(8080+i); // Different ports for different servers
        webServerNodes.Get(i)->AddApplication(server);
        server->SetStartTime(Seconds(0.0));
        server->SetStopTime(Seconds(simulation_time));
        web_servers.push_back(server);
    }
    
    // Setting up Proxy Server
    Ptr<ProxyServer> proxy=CreateObject<ProxyServer>();
    proxy->SetAttribute("Port", UintegerValue(8080));
    
    // Registering web servers with proxy
    for (uint32_t i=0; i<webServerNodes.GetN(); i++) {
        proxy->AddWebServer(interfaces.GetAddress(1+i), 8080+i);
    }
    
    proxyNode.Get(0)->AddApplication(proxy);
    proxy->SetStartTime(Seconds(0.0));
    proxy->SetStopTime(Seconds(simulation_time));
    
    // Setting up HTTP Clients
    std::vector<std::vector<std::string>> clientUrls = {
        {"/index.html", "/about.html", "/products.html", "/images/logo.jpg"},
        {"/index.html", "/data/api.json", "/videos/intro.mp4", "/documents/report.pdf"},
        {"/about.html", "/images/banner.png", "/products.html", "/data/api.json"},
        {"/index.html", "/images/logo.jpg", "/videos/intro.mp4", "/about.html"},
        {"/products.html", "/documents/report.pdf", "/images/banner.png", "/data/api.json"}
    };
    
    std::vector<Ptr<HttpClient>> clients;
    for (uint32_t i=0; i<clientNodes.GetN(); i++) {
        Ptr<HttpClient> client=CreateObject<HttpClient>(i);
        
        Address proxy_address(InetSocketAddress(interfaces.GetAddress(0), 8080));
        client->SetProxyServer(proxy_address);
        
        // Assign URLs to client
        std::vector<std::string> urls=clientUrls[i%clientUrls.size()];
        client->Setrequest_urls(urls);
        
        clientNodes.Get(i)->AddApplication(client);
        client->SetStartTime(Seconds(2.0+ i*0.5));
        client->SetStopTime(Seconds(simulation_time-1));
        clients.push_back(client);
    }
    
    Simulator::Schedule(Seconds(0.5), &LogThroughput);
    
    // Enable routing
    Ipv4GlobalRoutingHelper::PopulateRoutingTables();
    
    NS_LOG_INFO("Starting simulation with "<<no_clients<<" clients and "<<webServerNodes.GetN()<<" web servers...");
    
    Simulator::Stop(Seconds(simulation_time));
    Simulator::Run();
    
    // Print final statistics
    proxy->PrintStats();
    
    NS_LOG_INFO("Simulation completed successfully!");
    Simulator::Destroy();
    throughputLog.close();
    
    return 0;
}