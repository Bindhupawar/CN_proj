import matplotlib.pyplot as plt

requests = []
hit_ratio = []

with open("scratch/http_proxy/cache_stats.txt", "r") as f:
    for line in f:
        if line.strip():
            r, h = map(float, line.strip().split())
            requests.append(r)
            hit_ratio.append(h)  # Convert ratio to %

plt.figure(figsize=(7, 5))
plt.plot(requests, hit_ratio, marker='s', color='seagreen', linewidth=2)
plt.title("Cache Hit Ratio vs Number of Requests", fontsize=14)
plt.xlabel("Number of Requests", fontsize=12)
plt.ylabel("Cache Hit Ratio (%)", fontsize=12)
plt.grid(True, linestyle='--', alpha=0.6)
plt.tight_layout()
plt.show()
