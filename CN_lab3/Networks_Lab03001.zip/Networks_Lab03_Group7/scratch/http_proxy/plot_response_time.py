import matplotlib.pyplot as plt
import numpy as np

clients = []
response_times = []

with open("scratch/http_proxy/response_time.txt") as f:
    for line in f:
        if line.strip() == "" or line.startswith("#"):
            continue
        parts = line.split()
        if len(parts) >= 2:
            clients.append(int(parts[0]))
            response_times.append(float(parts[1]))


clients = np.array(clients)
response_times = np.array(response_times)

plt.figure(figsize=(8, 5))
plt.plot(clients, response_times, 'o-', color='blue', linewidth=2, markersize=6)

plt.xlabel("Number of Clients", fontsize=12)
plt.ylabel("Response Time (ms)", fontsize=12)
plt.title("Response Time vs Number of Clients", fontsize=14)

# 🔹 Show very small differences clearly
plt.ylim(min(response_times) - 0.005, max(response_times) + 0.005)
plt.gca().yaxis.set_major_formatter(plt.FuncFormatter(lambda y, _: f"{y:.3f}"))

# Grid and fine ticks for better readability
plt.grid(True, linestyle='--', alpha=0.6)
plt.minorticks_on()
plt.tight_layout()

plt.savefig("response_time_plot.png", dpi=300)
plt.show()
