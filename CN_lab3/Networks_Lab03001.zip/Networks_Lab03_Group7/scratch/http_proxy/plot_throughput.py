import matplotlib.pyplot as plt

# Load data: each line => "<time_s> <throughput_mbps>"
time = []
throughput = []

with open("throughput.txt", "r") as f:
    for line in f:
        if line.strip():
            t, th = map(float, line.strip().split())
            time.append(t)
            throughput.append(th)

plt.figure(figsize=(7, 5))
plt.plot(time, throughput, color='darkorange', linewidth=2)
plt.fill_between(time, throughput, color='orange', alpha=0.2)
plt.title("Throughput vs Simulation Time", fontsize=14)
plt.xlabel("Simulation Time (s)", fontsize=12)
plt.ylabel("Throughput (Rps)", fontsize=12)
plt.grid(True, linestyle='--', alpha=0.6)
plt.tight_layout()
plt.show()
