import matplotlib.pyplot as plt

retransmissions = []
loss_rate = []

with open("packet_loss_vs_retrans-task1b.txt", "r") as f:
    for line in f:
        if line.strip():
            r, loss = map(float, line.split())
            retransmissions.append(r)
            loss_rate.append(loss)

plt.figure(figsize=(8,5))
plt.plot(retransmissions, loss_rate, marker='o', color="crimson", linewidth=2, label="Loss Rate")

plt.title("Packet Loss Rate vs Retransmissions", fontsize=14)
plt.xlabel("Retransmissions", fontsize=12)
plt.ylabel("Packet Loss Rate (%)", fontsize=12)
plt.grid(True, linestyle="--", alpha=0.6)
plt.legend()
plt.tight_layout()
plt.savefig("loss_vs_retrans_plot.png", dpi=300)
plt.show()
