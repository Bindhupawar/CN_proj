import numpy as np
import matplotlib.pyplot as plt

# Load data
data = np.loadtxt('window_utilization-task1b.txt')
time = data[:, 0]
window_util = data[:, 1]

def smooth(y, box_pts=5):
    box = np.ones(box_pts)/box_pts
    y_smooth = np.convolve(y, box, mode='same')
    return y_smooth

window_util_smooth = smooth(window_util, box_pts=8)

# Plot
plt.figure(figsize=(10, 6))
plt.plot(time, window_util_smooth, color='royalblue', linewidth=2.5, label='Window Utilization (smoothed)')
plt.scatter(time, window_util, color='lightcoral', s=25, alpha=0.6, label='Raw Data')

plt.title("Window Utilization Over Time", fontsize=16, weight='bold', pad=15)
plt.xlabel("Time (s)", fontsize=13)
plt.ylabel("Window Utilization", fontsize=13)
plt.grid(True, linestyle='--', alpha=0.5)
plt.legend(fontsize=11)
plt.tight_layout()
plt.fill_between(time, window_util_smooth, color='skyblue', alpha=0.3)

plt.savefig("window_utilization_plot.png", dpi=300)
plt.show()
