import matplotlib.pyplot as plt

time = []
goodput_kbps = []

with open("goodput-task1b.txt", "r") as f:
    for line in f:
        if line.strip():
            t, g = map(float, line.split())
            time.append(t)
            goodput_kbps.append(g / 1000.0)  # convert to Kbps

plt.figure(figsize=(8,5))
plt.plot(time, goodput_kbps, color="darkgreen", linewidth=2, label="Goodput")

plt.title("Goodput vs Simulation Time", fontsize=14)
plt.xlabel("Time (s)", fontsize=12)
plt.ylabel("Goodput (Kbps)", fontsize=12)
plt.grid(True, linestyle="--", alpha=0.6)
plt.legend()
plt.tight_layout()
plt.savefig("goodput_plot.png", dpi=300)
plt.show()
