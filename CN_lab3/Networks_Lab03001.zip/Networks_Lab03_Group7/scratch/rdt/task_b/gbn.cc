#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/internet-module.h"
#include "ns3/point-to-point-module.h"
#include "ns3/applications-module.h"
#include <fstream>

using namespace ns3;
using namespace std;

NS_LOG_COMPONENT_DEFINE("GBN");

// Custom RDT Header
class RDTHeader: public Header {
private:
    uint32_t sequence_number;
    uint32_t ack_number;
    uint16_t check_sum;

public:

    RDTHeader(){
        sequence_number=0;
        ack_number=0;
        check_sum=0;
    }

    void SetSeq(uint32_t s){ 
        sequence_number=s; 
    }

    void SetAck(uint32_t a){ 
        ack_number=a; 
    }

    void Setcheck_sum(uint16_t c){ 
        check_sum=c;
    }

    uint32_t GetSeq() const { 
        return sequence_number; 
    }

    uint32_t GetAck() const { 
        return ack_number; 
    }

    uint16_t Getcheck_sum() const { 
        return check_sum; 
    }

    static TypeId GetTypeId(void) {
        static TypeId tid = TypeId("ns3::RDTHeader").SetParent<Header>().AddConstructor<RDTHeader>();
        return tid;
    }

    virtual TypeId GetInstanceTypeId(void) const { 
        return GetTypeId(); 
    }

    virtual void Print(std::ostream &os) const override {
        os<<"Seq="<<sequence_number<<" Ack="<<ack_number;
    }

    virtual uint32_t GetSerializedSize(void) const override { 
        return 10; 
    }

    virtual void Serialize(Buffer::Iterator start) const override {
        start.WriteHtonU32(sequence_number);
        start.WriteHtonU32(ack_number);
        start.WriteHtonU16(check_sum);
    }

    virtual uint32_t Deserialize(Buffer::Iterator start) override {
        sequence_number=start.ReadNtohU32();
        ack_number=start.ReadNtohU32();
        check_sum=start.ReadNtohU16();
        return 10;
    }

};

// Globals
Ptr<Socket> sender_socket, receiver_socket;
uint32_t base=0;
uint32_t next_seq_number=0;
uint32_t window_size=4;

double timeout_interval=0.5;
EventId retransmission_event;
bool awaiting_ack=false;

uint32_t expected_Seq=0;

uint32_t bytes_received=0;
uint32_t retransmissions=0;
uint32_t total_packets_sent=0;
uint32_t total_packets_lost=0;

std::ofstream windowLog("window_utilization-task1b.txt");
std::ofstream goodputLog("goodput-task1b.txt");
std::ofstream lossLog("packet_loss_vs_retrans-task1b.txt");

void LogWindowUtilization() {
  double currentTime=Simulator::Now().GetSeconds();
  double utilization=(double)(next_seq_number-base)/window_size;
  windowLog<<currentTime<<" "<<utilization<< "\n";
  Simulator::Schedule(Seconds(0.1), &LogWindowUtilization);
}

void LogGoodput() {
  double currentTime=Simulator::Now().GetSeconds();
  double goodput_bps=(bytes_received*8.0)/currentTime;
  goodputLog<<currentTime<<" "<<goodput_bps<<"\n";
  Simulator::Schedule(Seconds(0.5), &LogGoodput);
}

void LogLoss() {
  double lossRate=(double)total_packets_lost/total_packets_sent*100.0;
  lossLog<<retransmissions<<" "<<lossRate<<"\n";
  Simulator::Schedule(Seconds(0.5), &LogLoss);
}


// Timer
void StartTimer();
void StopTimer();
void TimeoutHandler();

void StopTimer() {
  if (retransmission_event.IsPending()) Simulator::Cancel(retransmission_event);
  awaiting_ack=false;
}

void TimeoutHandler() {

  NS_LOG_UNCOND("\nTimeout → Retransmitting window from base="<<base<<" to next_seq_number="<< next_seq_number-1);
  total_packets_lost++;
  
  for(uint32_t i=base; i<next_seq_number; i++) {
    Ptr<Packet> pkt=Create<Packet>(100);
    RDTHeader hdr;
    hdr.SetSeq(i);
    pkt->AddHeader(hdr);
    sender_socket->Send(pkt);
    retransmissions++;
    total_packets_sent++;
    NS_LOG_UNCOND("Retransmitted Packet SEQ="<<i);
  }
  StartTimer();
}

void StartTimer() {
  retransmission_event=Simulator::Schedule(Seconds(timeout_interval), &TimeoutHandler);
  awaiting_ack=true;
}

// Reciever
void ReceivePacket(Ptr<Socket> socket) {
  Ptr<Packet> packet=socket->Recv();
  RDTHeader hdr;
  packet->RemoveHeader(hdr);
  uint32_t seq=hdr.GetSeq();

  if (seq==expected_Seq) {
    bytes_received+=packet->GetSize();
    NS_LOG_UNCOND("Receiver: Got in-order packet SEQ="<<seq);
    expected_Seq++;

  } else {
    NS_LOG_UNCOND("Receiver: Out-of-order packet SEQ="<<seq<< " expected="<<expected_Seq);
  }

  // Always send cumulative ACK for last in-order packet
  Ptr<Packet> ackPkt=Create<Packet>();
  RDTHeader ackHdr;
  ackHdr.SetAck(expected_Seq-1);
  ackPkt->AddHeader(ackHdr);
  socket->SendTo(ackPkt, 0, InetSocketAddress(Ipv4Address("10.1.1.1"), 8080));
  NS_LOG_UNCOND("Receiver: Sent Cumulative ACK=" << expected_Seq-1);

}

// Sender
void SendPacket() {

  if(next_seq_number<base+window_size) {
    Ptr<Packet> pkt = Create<Packet>(100);
    RDTHeader hdr;
    hdr.SetSeq(next_seq_number);
    pkt->AddHeader(hdr);
    sender_socket->Send(pkt);
    total_packets_sent++;

    NS_LOG_UNCOND("\nSender: Sent Packet SEQ="<<next_seq_number);

    if(base==next_seq_number && !awaiting_ack) StartTimer();

    next_seq_number++;
    Simulator::Schedule(Seconds(0.1), &SendPacket);

  }

}

void ReceiveAck(Ptr<Socket> socket) {
  Ptr<Packet> packet=socket->Recv();
  RDTHeader hdr;
  packet->RemoveHeader(hdr);
  uint32_t ack=hdr.GetAck();
  NS_LOG_UNCOND("Sender: Received ACK="<<ack);

  if(ack>=base) {
    base=ack+1;
    if(base==next_seq_number) {
      StopTimer();
    } 
    else {
      StopTimer();
      StartTimer();
    }
  }

  // if(base<total_packets) 
  Simulator::Schedule(Seconds(0.05), &SendPacket);
}


// Main
int main(int argc, char *argv[]) {
  LogComponentEnable("GBN", LOG_LEVEL_INFO);

  NodeContainer nodes;
  nodes.Create(2);

  PointToPointHelper p2p;
  p2p.SetDeviceAttribute("DataRate", StringValue("1Mbps"));
  p2p.SetChannelAttribute("Delay", StringValue("10ms"));
  NetDeviceContainer devices=p2p.Install(nodes);

  InternetStackHelper stack;
  stack.Install(nodes);

  Ipv4AddressHelper address;
  address.SetBase("10.1.1.0", "255.255.255.0");
  Ipv4InterfaceContainer interfaces=address.Assign(devices);

  // Error models
  Ptr<RateErrorModel> em1=CreateObject<RateErrorModel>();
  Ptr<RateErrorModel> em2=CreateObject<RateErrorModel>();
  em1->SetAttribute("ErrorRate", DoubleValue(0.05));
  em1->SetAttribute("ErrorUnit", StringValue("ERROR_UNIT_PACKET"));
  em2->SetAttribute("ErrorRate", DoubleValue(0.05));
  em2->SetAttribute("ErrorUnit", StringValue("ERROR_UNIT_PACKET"));
  devices.Get(1)->SetAttribute("ReceiveErrorModel", PointerValue(em1));
  devices.Get(0)->SetAttribute("ReceiveErrorModel", PointerValue(em2));

  // Sockets
  sender_socket=Socket::CreateSocket(nodes.Get(0), TypeId::LookupByName("ns3::UdpSocketFactory"));
  receiver_socket=Socket::CreateSocket(nodes.Get(1), TypeId::LookupByName("ns3::UdpSocketFactory"));

  InetSocketAddress receiverAddr=InetSocketAddress(interfaces.GetAddress(1), 8080);
  sender_socket->Connect(receiverAddr);

  InetSocketAddress localAddr=InetSocketAddress(Ipv4Address::GetAny(), 8080);
  receiver_socket->Bind(localAddr);
  receiver_socket->SetRecvCallback(MakeCallback(&ReceivePacket));

  Ptr<Socket> ackSocket=Socket::CreateSocket(nodes.Get(0), TypeId::LookupByName("ns3::UdpSocketFactory"));
  InetSocketAddress ackLocal=InetSocketAddress(Ipv4Address::GetAny(), 8080);
  ackSocket->Bind(ackLocal);
  ackSocket->SetRecvCallback(MakeCallback(&ReceiveAck));

  Simulator::Schedule(Seconds(0.1), &LogWindowUtilization);
  Simulator::Schedule(Seconds(0.5), &LogGoodput);
  Simulator::Schedule(Seconds(0.5), &LogLoss);

  Simulator::Schedule(Seconds(1.0), &SendPacket);
  Simulator::Stop(Seconds(20.0));
  Simulator::Run();

  NS_LOG_UNCOND("\nSimulation Finished!");
  NS_LOG_UNCOND("Bytes received: "<<bytes_received);
  NS_LOG_UNCOND("Retransmissions: "<<retransmissions);
  NS_LOG_UNCOND("Goodput: "<<(bytes_received*8.0/20.0/1000)<<" Kbps");

  Simulator::Destroy();

  
  lossLog.close();
  windowLog.close();
  goodputLog.close();

  return 0;
}
