#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/internet-module.h"
#include "ns3/point-to-point-module.h"
#include "ns3/applications-module.h"

using namespace ns3;
using namespace std;

NS_LOG_COMPONENT_DEFINE("ABP");

// Custom RDT Header
class RDTHeader: public Header {
private:
    uint32_t sequence_number;
    uint32_t ack_number;
    uint16_t check_sum;

public:

    RDTHeader(){
        sequence_number=0;
        ack_number=0;
        check_sum=0;
    }

    void SetSeq(uint32_t s){ 
        sequence_number=s; 
    }

    void SetAck(uint32_t a){ 
        ack_number=a; 
    }

    void Setcheck_sum(uint16_t c){ 
        check_sum=c;
    }

    uint32_t GetSeq() const { 
        return sequence_number; 
    }

    uint32_t GetAck() const { 
        return ack_number; 
    }

    uint16_t Getcheck_sum() const { 
        return check_sum; 
    }

    static TypeId GetTypeId(void) {
        static TypeId tid = TypeId("ns3::RDTHeader").SetParent<Header>().AddConstructor<RDTHeader>();
        return tid;
    }

    virtual TypeId GetInstanceTypeId(void) const { 
        return GetTypeId(); 
    }

    virtual void Print(std::ostream &os) const override {
        os<<"Seq="<<sequence_number<<" Ack="<<ack_number;
    }

    virtual uint32_t GetSerializedSize(void) const override { 
        return 10; 
    }

    virtual void Serialize(Buffer::Iterator start) const override {
        start.WriteHtonU32(sequence_number);
        start.WriteHtonU32(ack_number);
        start.WriteHtonU16(check_sum);
    }

    virtual uint32_t Deserialize(Buffer::Iterator start) override {
        sequence_number=start.ReadNtohU32();
        ack_number=start.ReadNtohU32();
        check_sum=start.ReadNtohU16();
        return 10;
    }

};

// Globals
Ptr<Socket> sender_socket, reciever_socket;
uint32_t sequence_number=0;
uint32_t expected_Seq=0;
uint32_t packets_sent=0;
uint32_t retransmissions=0;
uint64_t bytes_received=0;

std::map<double,uint32_t> retransmissionsTime;
std::map<double,double> throughputTime;


double simStartTime=0.0;

void RecordRetransmission()
{
  double t=Simulator::Now().GetSeconds();
  retransmissions++;
  retransmissionsTime[t]=retransmissions;
}

void RecordThroughput(uint32_t bytes)
{
  double t = Simulator::Now().GetSeconds();
  bytes_received+=bytes;
  throughputTime[t]=(bytes_received*8.0)/t; // bits/sec
}

uint32_t packet_number=0;
bool awaiting_ack=false;
EventId retransmission_event;
double timeout_interval=0.2; // seconds

// Timer
void StartTimer();
void StopTimer();
void TimeoutHandler();

void StopTimer() {
  if (retransmission_event.IsPending()) Simulator::Cancel(retransmission_event);
}

void StartTimer() {
  retransmission_event=Simulator::Schedule(Seconds(timeout_interval), &TimeoutHandler);
}

void TimeoutHandler() {
  NS_LOG_UNCOND("Timeout for seq="<<sequence_number<<" → Retransmitting Packet "<<packet_number<<"...");
  retransmissions++;
  RecordRetransmission();
  Ptr<Packet> packet=Create<Packet>(100);
  RDTHeader hdr;
  hdr.SetSeq(sequence_number);
  hdr.SetAck(0);
  packet->AddHeader(hdr);

  sender_socket->Send(packet);
  packets_sent++;
  awaiting_ack=true;
  StartTimer();
}

// Receiver side
void ReceivePacket(Ptr<Socket> socket){

  Ptr<Packet> packet=socket->Recv();
  RDTHeader hdr;
  packet->RemoveHeader(hdr);

  uint32_t recieved_Seq=hdr.GetSeq();

  if (recieved_Seq==expected_Seq){
    NS_LOG_UNCOND("Receiver: Got correct packet SEQ="<<recieved_Seq<<", Packet No "<<packet_number);
    RecordThroughput(packet->GetSize());
    // Send ACK
    Ptr<Packet> ackPkt=Create<Packet>();
    RDTHeader ackHdr;
    ackHdr.SetAck(recieved_Seq);
    ackPkt->AddHeader(ackHdr);
    socket->SendTo(ackPkt, 0, InetSocketAddress(Ipv4Address("10.1.1.1"), 8080));
    expected_Seq=1-expected_Seq;

  } 
  else {

    // Send DUP ACK
    Ptr<Packet> ackPkt=Create<Packet>();
    RDTHeader ackHdr;
    ackHdr.SetAck(1-expected_Seq);
    ackPkt->AddHeader(ackHdr);
    socket->SendTo(ackPkt, 0, InetSocketAddress(Ipv4Address("10.1.1.1"), 8080));
    NS_LOG_UNCOND("Receiver: Sent Duplicate ACK for wrong packet rec_seq="<<recieved_Seq<<" expected="<<expected_Seq);

  }
}

// Sender side
void SendPacket() {
  if (awaiting_ack)
    return;

  Ptr<Packet> packet=Create<Packet>(100);
  RDTHeader hdr;
  hdr.SetSeq(sequence_number);
  hdr.SetAck(0);
  packet->AddHeader(hdr);

  packet_number++;
  sender_socket->Send(packet);
  packets_sent++;
  awaiting_ack=true;
  StartTimer();

  NS_LOG_UNCOND("\nSender: Sent packet SEQ="<<sequence_number<<", Packet No "<<packet_number);

}

void ReceiveAck(Ptr<Socket> socket) {
  Ptr<Packet> packet=socket->Recv();
  RDTHeader hdr;
  packet->RemoveHeader(hdr);

  uint32_t ack_number=hdr.GetAck();
  if (ack_number==sequence_number) {
    NS_LOG_UNCOND("Sender: Received ACK for SEQ="<<ack_number<<" for Packet No "<<packet_number);
    StopTimer();
    awaiting_ack=false;
    sequence_number=1-sequence_number;

    // Send next packet after small delay
    Simulator::Schedule(Seconds(0.1), &SendPacket);
  } 
  else {
    NS_LOG_UNCOND("Sender: Wrong ACK, ignored.");
  }
}


int main(int argc, char *argv[]) {

    LogComponentEnable("ABP", LOG_LEVEL_INFO);
    LogComponentEnable("UdpSocketImpl", LOG_LEVEL_ERROR);

    NodeContainer nodes;
    nodes.Create(2);

    PointToPointHelper p2p;
    p2p.SetDeviceAttribute("DataRate", StringValue("1Mbps"));
    p2p.SetChannelAttribute("Delay", StringValue("10ms"));
    NetDeviceContainer devices=p2p.Install(nodes);

    InternetStackHelper stack;
    stack.Install(nodes);

    Ipv4AddressHelper address;
    address.SetBase("10.1.1.0", "255.255.255.0");
    Ipv4InterfaceContainer interfaces=address.Assign(devices);

    // Error model
    Ptr<RateErrorModel> em1 = CreateObject<RateErrorModel>();
    Ptr<RateErrorModel> em2 = CreateObject<RateErrorModel>();

    em1->SetAttribute("ErrorRate", DoubleValue(0.2));
    em1->SetAttribute("ErrorUnit", StringValue("ERROR_UNIT_PACKET"));

    em2->SetAttribute("ErrorRate", DoubleValue(0.2));
    em2->SetAttribute("ErrorUnit", StringValue("ERROR_UNIT_PACKET"));

    devices.Get(0)->SetAttribute("ReceiveErrorModel", PointerValue(em1));
    devices.Get(1)->SetAttribute("ReceiveErrorModel", PointerValue(em2));


    // Create sockets
    sender_socket=Socket::CreateSocket(nodes.Get(0),TypeId::LookupByName("ns3::UdpSocketFactory"));
    reciever_socket=Socket::CreateSocket(nodes.Get(1),TypeId::LookupByName("ns3::UdpSocketFactory"));

    InetSocketAddress receiverAddr=InetSocketAddress(interfaces.GetAddress(1), 8080);
    sender_socket->Connect(receiverAddr);

    InetSocketAddress localAddr=InetSocketAddress(Ipv4Address::GetAny(), 8080);
    reciever_socket->Bind(localAddr);
    reciever_socket->SetRecvCallback(MakeCallback(&ReceivePacket));

    // Separate socket for ACK reception
    Ptr<Socket> ackSocket=Socket::CreateSocket(nodes.Get(0), TypeId::LookupByName("ns3::UdpSocketFactory"));
    InetSocketAddress ackLocal=InetSocketAddress(Ipv4Address::GetAny(), 8080);
    ackSocket->Bind(ackLocal);
    ackSocket->SetRecvCallback(MakeCallback(&ReceiveAck));

    Simulator::Schedule(Seconds(1.0), &SendPacket);
    Simulator::Stop(Seconds(20.0));
    Simulator::Run();

    NS_LOG_UNCOND("Simulation finished.");
    NS_LOG_UNCOND("Packets sent: "<<packets_sent);
    NS_LOG_UNCOND("Retransmissions: "<<retransmissions);
    NS_LOG_UNCOND("Bytes received: "<<bytes_received);
    NS_LOG_UNCOND("Throughput: "<<(bytes_received*8.0/20.0/1000) << " Kbps");

    Simulator::Destroy();

    std::ofstream file1("retransmissions-task1a.txt");
    for(auto &entry: retransmissionsTime){
      file1<<entry.first <<" " <<entry.second<<"\n";
    }
    file1.close();

    std::ofstream file2("throughput-task1a.txt");
    for(auto &entry: throughputTime){
      file2<<entry.first<<" "<<entry.second<<"\n";
    }
    file2.close();
    NS_LOG_UNCOND("Results saved: retransmissions-task1a.txt, throughput-task1a.txt");

    return 0;
}
