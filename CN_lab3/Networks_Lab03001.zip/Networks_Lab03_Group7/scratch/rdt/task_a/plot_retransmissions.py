import matplotlib.pyplot as plt

# Read data from file
times=[]
retransmissions=[]

with open("retransmissions-task1a.txt", "r") as f:
    for line in f:
        if line.strip():
            t, r = map(float, line.split())
            times.append(t)
            retransmissions.append(r)

# Plot
plt.figure(figsize=(8, 5))
plt.plot(times, retransmissions, color="royalblue", linewidth=2, label="Retransmissions")

plt.title("Retransmissions vs Simulation Time", fontsize=14)
plt.xlabel("Simulation Time (s)", fontsize=12)
plt.ylabel("Number of Retransmissions", fontsize=12)
plt.grid(True, linestyle="--", alpha=0.6)
plt.legend()
plt.tight_layout()

plt.savefig("retransmissions_plot.png", dpi=300)
plt.show()
