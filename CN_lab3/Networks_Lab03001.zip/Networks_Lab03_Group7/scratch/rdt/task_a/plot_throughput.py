import matplotlib.pyplot as plt

# Read data from file
times = []
throughput = []

with open("throughput-task1a.txt", "r") as f:
    for line in f:
        if line.strip():
            t, th = map(float, line.split())
            times.append(t)
            throughput.append(th / 1e3)  # convert to Kbps for readability

# Plot
plt.figure(figsize=(8, 5))
plt.plot(times, throughput, color="darkorange", linewidth=2, label="Throughput")

plt.title("Throughput vs Simulation Time", fontsize=14)
plt.xlabel("Simulation Time (s)", fontsize=12)
plt.ylabel("Throughput (Kbps)", fontsize=12)
plt.grid(True, linestyle="--", alpha=0.6)
plt.legend()
plt.tight_layout()

plt.savefig("throughput_plot.png", dpi=300)
plt.show()
