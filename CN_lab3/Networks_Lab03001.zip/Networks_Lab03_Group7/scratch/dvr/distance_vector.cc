#include <bits/stdc++.h>
using namespace std;

const int INF=1e9;
const int max_rounds=10;

enum Mode {
    COUNT_TO_INFINITY,
    SPLIT_HORIZON,
    POISON_REVERSE
};

// Network Nodes
class Node {
public:
    string name;
    int id;
    vector<int> dist;        // Distance to each destination
    vector<int> prev_dist;   // Previous round's distances
    vector<int> next_hop;    // Next hop for each destination
    unordered_map<int, int> neighbors; // neighbor -> cost

    Node(string n= "", int idx=0) {
        name=n;
        id=idx;
    }

    void initialize(int n) {
        dist.assign(n,INF);
        prev_dist.assign(n,INF);
        next_hop.assign(n,-1);
        dist[id]=0;
        next_hop[id]=id;
    }

    void add_link(int neighbor, int cost) {
        neighbors[neighbor]=cost;
        dist[neighbor]=cost;
        next_hop[neighbor]=neighbor;
    }

    bool update(const vector<Node> &allNodes, Mode mode) {
        bool changed=false;
        prev_dist=dist;

        for(int dest=0; dest<(int)dist.size(); dest++) {

            if (dest==id) {
                dist[dest]=0;
                next_hop[dest]=id;
                continue;
            }

            int best=INF;
            int best_hop=-1;

            for(auto &[nbr,cost]: neighbors) {

                if(cost>=INF) continue;
                int nbrDist=allNodes[nbr].prev_dist[dest];

                // Split Horizon
                if ( mode==SPLIT_HORIZON && allNodes[nbr].next_hop[dest]==id)
                    continue;

                // Poison Reverse
                if ( mode==POISON_REVERSE && allNodes[nbr].next_hop[dest]==id)
                    nbrDist=INF;

                int candidate=cost+nbrDist;
                if (candidate<best) {
                    best=candidate;
                    best_hop=nbr;
                }
            }

            if(best!=dist[dest]) {
                cout << "Node " << name << " updates distance to "
                     << char('A' + dest) << " from "
                     << (dist[dest] >= INF ? "INF" : to_string(dist[dest]))
                     << " to "
                     << (best >= INF ? "INF" : to_string(best))
                     << " (via " << (best_hop == -1 ? '-' : char('A' + best_hop))
                     << ")\n";
                dist[dest]=best;
                next_hop[dest]=best_hop;
                changed=true;
            }
        }
        return changed;
    }

    void print_table() const {
        cout<<"Node "<<name<<": ";
        for(int d : dist){
            cout<<(d >= INF ? "INF " : " " + to_string(d) + "  ");
        }
        cout<<"\n";
    }
};

// Network Simulations
class Network {
public:
    vector<Node> nodes;

    void add_node(string name) {
        int idx=nodes.size();
        nodes.emplace_back(name, idx);
        for (auto &n: nodes){
            n.initialize(nodes.size());
        }
    }

    void add_link(int i, int j, int cost) {
        nodes[i].add_link(j,cost);
        nodes[j].add_link(i,cost);
    }

    void remove_link(int i, int j) {
        nodes[i].neighbors[j]=INF;
        nodes[j].neighbors[i]=INF;
        nodes[i].dist[j]=INF;
        nodes[j].dist[i]=INF;
        nodes[i].prev_dist[j]=INF;
        nodes[j].prev_dist[i]=INF;

        for(int k=0;k<nodes.size();k++){
            if(nodes[i].next_hop[k]==j) nodes[i].next_hop[k]=-1;
        }
        for(int k=0;k<nodes.size();k++){
            if(nodes[j].next_hop[k]==i) nodes[j].next_hop[k]=-1;
        }
        

    }

    bool run_round(Mode mode) {
        bool changed=false;
        for(auto &node: nodes){
            node.prev_dist=node.dist;
        }
        for(auto &node: nodes){
            if(node.update(nodes,mode)){
                changed=true;
            }
        }
        return changed;
    }

    void print_all() const {
        cout<<"\n";
        for(auto &node: nodes) {
            node.print_table();
        }
        cout<<"\n";
    }

    int run_until_converged(Mode mode, bool afterFailure=false) {
        int round=0;
        while(round<max_rounds){
            round++;
            cout<<"Round "<<round<<":\n";
            bool changed=run_round(mode);
            print_all();
            if(!changed) break;
        }
        return round;
    }
};

void run_simulation(Mode mode, const string &mode_name) {
    cout<<"====================================================\n";
    cout<<"Running Simulation for Mode: "<<mode_name<<"\n";
    cout<<"====================================================\n";

    Network net;
    net.add_node("A");
    net.add_node("B");
    net.add_node("C");
    net.add_node("D");

    // Topology: A-B (1), B-C (1), C-D (2), A-C (3), B-D (1)
    net.add_link(0, 1, 1);
    net.add_link(1, 2, 1);
    net.add_link(2, 3, 2);
    net.add_link(0, 2, 3);
    net.add_link(1, 3, 1);

    // net.add_node("A");
    // net.add_node("B");
    // net.add_node("C");
    // net.add_node("D");
    // net.add_node("E");
    // net.add_node("F");
    // net.add_node("G");
    // net.add_node("H");
    // net.add_node("I");

    // net.add_link(0, 1, 8);
    // net.add_link(1, 2, 1);
    // net.add_link(0, 3, 1);
    // net.add_link(1, 4, 1);
    // net.add_link(3, 4, 1);
    // net.add_link(4, 5, 1);
    // net.add_link(3, 6, 1);
    // net.add_link(4, 7, 1);
    // net.add_link(5, 8, 1);
    // net.add_link(6, 7, 1);
    // net.add_link(7, 8, 1);

    // Initial state
    cout<<"\nIntial Topology/State:\n";
    for(auto &n: net.nodes) {
        n.print_table();
    }
    cout<<"\n";

    // Initial convergence
    int rounds=net.run_until_converged(mode);
    if(rounds<max_rounds){
        cout<<"\n*** Converged in "<<rounds<<" rounds! ***\n\n";
    }
    else{
        cout<<"\n*** Not Converged till "<<rounds<<" rounds! May be count to infinity problem, increase max_rounds***\n\n";
    }

    // Simulating failure
    cout<<"*** Link B-D fails ***\n";
    net.remove_link(1, 3);

    // cout<<"*** Link B-C fails ***\n";
    // net.remove_link(1, 2);
    cout<<"\nNew Topology/State:\n";
    for(auto &n: net.nodes) {
        n.print_table();
    }
    cout<<"\n";

    rounds=net.run_until_converged(mode, true);
    if(rounds<max_rounds){
        cout<<"\n*** Converged in "<<rounds<<" rounds! ***\n\n";
    }
    else{
        cout<<"\n*** Not Converged till "<<rounds<<" rounds! May be count to infinity problem, increase max_rounds***\n\n";
    }
}

int main() {
    run_simulation(COUNT_TO_INFINITY, "COUNT-TO-INFINITY");
    run_simulation(SPLIT_HORIZON, "SPLIT-HORIZON");
    run_simulation(POISON_REVERSE, "POISON-REVERSE");
    return 0;
}
