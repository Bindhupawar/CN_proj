#include <bits/stdc++.h>
#include <thread>

using namespace std;

struct InputSource {
    int P;              // packets per second (rate)
    int Lmin, Lmax;     // packet size (bytes)
    double w;           // weight
    double tb,te;       // fractions of T start and end
};

struct Packet {
    uint64_t id;
    int source;         // source index 
    int size;           // bytes
    double arrival;     // seconds
    void print() const {
        cerr << "Packet id:0x" << std::hex << std::setw(16) << std::setfill('0') << id << ", source:" << source << ", size:" << size << ", arrival:" << arrival << std::endl;
    }
};

struct Metrics {
    double server_utilization=0.0;
    double avg_pkt_delay=0.0;
    double pkt_drop_prob=0.0;
    double fairness=0.0;
};

static std::mt19937_64 rng(123456789);

vector<Packet> generate_arrivals_for_source(int source_id, const InputSource &s, double T) {

    vector<Packet> out;
    double start=s.tb*T;
    double end=s.te*T;

    if (end <= start) return out;

    std::exponential_distribution<double> inter_arrival_times( (double)s.P ); // mean 1/P
    std::uniform_int_distribution<int> size_dist(s.Lmin, s.Lmax);

    double t=start;
    uint64_t counter=0;
    while(true){

        double ia=inter_arrival_times(rng);
        t+=ia;

        if( t>end || t>T ) break;

        Packet p;
        p.id=((uint64_t)source_id<<48)^(counter); // Packet ID (64 bits): SOURCE_ID(First 16 bits) + counter (48 bits) -- Max packets from each source = 2^48
        counter++;

        p.source=source_id;
        p.size=size_dist(rng);
        p.arrival=t;
        out.push_back(p);

    }
    return out;

}

vector<Packet> generate_all_arrivals(const vector<InputSource>& sources, double T) {

    int N=sources.size();
    vector<vector<Packet>> per_source(N);
    vector<thread> threads;

    // Creating arrivals for each source
    for(int i=0; i<N; i++){
        threads.emplace_back([i, &sources, T, &per_source]() {
            per_source[i]=generate_arrivals_for_source(i, sources[i], T);
        });
    }
    for (auto &th:threads) {
        th.join();
    }

    // Merging all arrivals
    vector<Packet> all;
    for(int i=0; i<N; i++){
        all.insert(all.end(), per_source[i].begin(), per_source[i].end());
    }

    // Custom sorting to sort according to arrival timings
    sort(all.begin(), all.end(), [](const Packet&a,const Packet&b){
        if (a.arrival != b.arrival) return a.arrival < b.arrival;
        else return a.id < b.id;
    });
    return all;

}

Metrics simulate_FCFS(const vector<Packet>& arrivals, const vector<InputSource>& sources, double T, double C, int B) {

    Metrics M;
    int idx=0; 
    int total_arrivals=arrivals.size();

    deque<Packet> buf;
    uint64_t dropped=0;

    double current_time=0.0;
    double busy_time=0.0;

    vector<uint64_t> bytes_sent_per_flow(sources.size(), 0);

    double sum_delays=0.0;
    uint64_t transmitted=0;

    //cerr<<"FCFS\n\n";
    // During transmission, enqueue arrivals that arrive before finish and service one at a time
    while ( idx<total_arrivals || !buf.empty() ) {
        
        if(buf.empty() && idx<total_arrivals && arrivals[idx].arrival>current_time) {
            current_time=arrivals[idx].arrival;
        }

        while ( idx<total_arrivals && arrivals[idx].arrival<=current_time ) {

            const Packet &p=arrivals[idx];
            idx++;

            if ( (int)buf.size()<B ) {
                buf.push_back(p);
            } 
            else {
                // FCFS tail drop: drop incoming packet
                // cerr<<"Dropped  ";
                // p.print();
                dropped++;
            }
    
        }

        if (buf.empty()) continue;

        // Transmit head packet
        Packet p=buf.front(); 
        buf.pop_front();

        double service = (double)p.size/C;
        double start_service = max(current_time, p.arrival);
        double finish = start_service+service;
        busy_time += service;

        current_time = finish;
        bytes_sent_per_flow[p.source] += p.size;
        sum_delays += (finish-p.arrival);
        transmitted++;

    }

    M.server_utilization = busy_time / T;
    M.pkt_drop_prob = (double)dropped / (double)max<uint64_t>(1, total_arrivals);
    M.avg_pkt_delay = transmitted ? (sum_delays/transmitted) : 0.0;
    
    // Jain's fairness based on throughput (bytes sent)
    vector<double> xi(sources.size());
    double sum=0.0;
    double sum_squared=0.0;

    for(size_t i=0; i<sources.size(); i++){
        xi[i] = (double)bytes_sent_per_flow[i];
        sum += xi[i];
        sum_squared += xi[i]*xi[i];
    }
    if (sum_squared==0) M.fairness=1.0;
    else M.fairness = (sum*sum) / ((double)sources.size()*sum_squared);
    return M;

}


Metrics simulate_WFQ(const vector<Packet>& arrivals, const vector<InputSource>& sources, double T, double C, int B) {
    
    Metrics M;
    int idx=0;
    int total_arrivals=arrivals.size();
    
    vector<deque<Packet>> buf(sources.size());
    
    uint64_t dropped=0;
    double current_time=0.0;
    double busy_time=0.0;
    
    vector<uint64_t> bytes_sent_per_flow(sources.size(), 0);
    
    double sum_delays=0.0;
    uint64_t transmitted=0;
    
    
    auto all_buffers_empty = [&]() {
        for (const auto& queue : buf) {
            if (!queue.empty()) return false;
        }
        return true;
    };
    
    //cerr<<"\n\nWFQ\n\n";
    while (idx < total_arrivals || !all_buffers_empty()) {
        
        int total_packets_in_buffer = 0;
        for (const auto& queue : buf) {
            total_packets_in_buffer+=queue.size();
        }

       
        if (total_packets_in_buffer==0 && idx < total_arrivals && arrivals[idx].arrival>current_time) {
            current_time = arrivals[idx].arrival;
        }
        

        while (idx<total_arrivals && arrivals[idx].arrival<=current_time) {
           
            int source_id = arrivals[idx].source;
            
            // Check if buffer has space (total buffer constraint)
            if (total_packets_in_buffer < B) {
                buf[source_id].push_back(arrivals[idx]);
                total_packets_in_buffer++;
            } else {
                // Drop incoming packet
                // cerr<<"Dropped  ";
                // arrivals[idx].print();
                dropped++;
            }
            idx++;
        }

        if (all_buffers_empty()) {
            continue;
        }
        
        int minsize_packet_idx=-1;
        double minsize=1e18; 
        double minsize_arrival=T+1.0;
        double max_weight=-1.0;

        for (int i=0; i<buf.size(); i++) {

            if (!buf[i].empty()) { 
                Packet p=buf[i].front();
                if ((double)p.size/sources[p.source].w <= minsize) {
                    if (p.size == minsize) {
                        if (p.arrival <= minsize_arrival) {
                            if (p.arrival == minsize_arrival) {
                                if (sources[p.source].w > max_weight) {
                                    minsize = (double)p.size/sources[p.source].w;
                                    minsize_packet_idx = i;
                                    minsize_arrival = p.arrival;
                                    max_weight = sources[p.source].w;
                                }
                            } 
                            else {
                                minsize = (double)p.size/sources[p.source].w;
                                minsize_packet_idx = i;
                                minsize_arrival = p.arrival;
                                max_weight = sources[p.source].w;
                            }
                        }
                    } 
                    else {
                        minsize = (double)p.size/sources[p.source].w;
                        minsize_packet_idx = i;
                        minsize_arrival = p.arrival;
                        max_weight = sources[p.source].w;
                    }
                }
            }

        }


        Packet p;
        if (minsize_packet_idx!=-1 && !buf[minsize_packet_idx].empty()) {
            p=buf[minsize_packet_idx].front();
            buf[minsize_packet_idx].pop_front();
        } 
        else {
            continue;
        }

        double start_service = max(current_time, p.arrival);
        double service = (double)p.size/C;
        double finish = start_service+service;
        busy_time += service;
        
        current_time = finish;
        bytes_sent_per_flow[p.source] += p.size;
        sum_delays += (finish-p.arrival);
        transmitted++;

    }

    M.server_utilization = busy_time / T;
    M.pkt_drop_prob = (double)dropped / (double)max<uint64_t>(1, total_arrivals);
    M.avg_pkt_delay = transmitted ? (sum_delays/transmitted) : 0.0;
    
    // Jain's fairness based on throughput (bytes sent)
    vector<double> xi(sources.size());
    double sum=0.0;
    double sum_squared=0.0;

    for(size_t i=0; i<sources.size(); i++){
        xi[i] = (double)bytes_sent_per_flow[i];
        sum += xi[i];
        sum_squared += xi[i]*xi[i];
    }
    if (sum_squared==0) M.fairness=1.0;
    else M.fairness = (sum*sum) / ((double)sources.size()*sum_squared);
    return M;

}

int main(int argc, char** argv) {

    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    string firstline;
    if(!getline(cin,firstline)) {
        cerr<<"No input\n"; return 1;
    }

    // Parsing firstline
    int N=0; double T; double C; int B;
    {
        replace(firstline.begin(),firstline.end(),'=',' ');
        replace(firstline.begin(),firstline.end(),'\t',' ');
        stringstream ss(firstline);
        string key;
        while (ss >> key) {
            if (key == "N") ss >> N;
            else if (key == "T") ss >> T;
            else if (key == "C") ss >> C;
            else if (key == "B") ss >> B;
        }
    }

    vector<InputSource> sources;
    sources.reserve(N);
    for (int i=0;i<N;i++){
        string line;
        if(!getline(cin, line)) {
            cerr<<"Insufficient source lines\n"; return 1;
        }
        if(line.size()==0){ 
            i--; 
            continue; 
        }
        stringstream ss(line);
        InputSource s;
        ss >> s.P >> s.Lmin >> s.Lmax >> s.w >> s.tb >> s.te;
        sources.push_back(s);
    }

    // Generating arrivals (multithreaded)
    vector<Packet> arrivals=generate_all_arrivals(sources, T);
    
    cerr<<"Generated total packets: "<<arrivals.size()<<"\n";

    // Simulating FCFS and WFQ separately using same arrivals
    Metrics m_fcfs=simulate_FCFS(arrivals, sources, T, C, B);
    Metrics m_wfq=simulate_WFQ(arrivals, sources, T, C, B);

    // Output results
    cout << fixed << setprecision(6);
    cout << "Simulation Summary:\n\n";
    cout << "Simulation time T = " << T << " seconds\n";
    cout << "Link capacity C = " << C << " bytes/s\n";
    cout << "Buffer capacity B = " << B << " packets\n";
    cout << "Number of generated packets = " << arrivals.size() << "\n\n";

    cout << "Algorithm: FCFS\n";
    cout << "Server Utilization = " << m_fcfs.server_utilization << "\n";
    cout << "Average Packet Delay (s) = " << m_fcfs.avg_pkt_delay << "\n";
    cout << "Packet Drop Probability = " << m_fcfs.pkt_drop_prob << "\n";
    cout << "Jain's Fairness Index = " << m_fcfs.fairness << "\n\n";

    cout << "Algorithm: WFQ\n";
    cout << "Server Utilization = " << m_wfq.server_utilization << "\n";
    cout << "Average Packet Delay (s) = " << m_wfq.avg_pkt_delay << "\n";
    cout << "Packet Drop Probability = " << m_wfq.pkt_drop_prob << "\n";
    cout << "Jain's Fairness Index = " << m_wfq.fairness << "\n\n";

    return 0;
}
